-- ======================================================================================================================================================================================================
-- author:			�ukasz D�browski
-- company:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				lukaszdabrowski.com
-- creation date:	2016-06-26
-- description:		Removes from input string all characters that are different from charcters provided as a second parameter.
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- ======================================================================================================================================================================================================

IF OBJECT_ID('REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED') IS NOT NULL
 DROP FUNCTION REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED
GO

CREATE FUNCTION [dbo].[REMOVE_ALL_CHARS_FROM_STRING_EXCEPT_FOR_EXPLICITLY_PROVIDED]
(
	@P_INPUT_NAME AS NVARCHAR(MAX),
	@P_LIST_OF_COMMA_SEPARATED_CHARS_TO_EXCLUDE_FROM_REPLACEMENT AS NVARCHAR(MAX)
) RETURNS NVARCHAR(MAX)
AS
BEGIN
 DECLARE 
	@START AS INT = 1,
	@STOP AS INT = 128,
	@EMPTY_STRING AS VARCHAR = '',
	@OUTPUT_NAME AS NVARCHAR(MAX) = ISNULL(@P_INPUT_NAME, '')


 IF @OUTPUT_NAME <> ''
  BEGIN
	 WHILE @START <= @STOP
	  BEGIN
	   IF CHARINDEX(CHAR(@START), @P_LIST_OF_COMMA_SEPARATED_CHARS_TO_EXCLUDE_FROM_REPLACEMENT) > 0
		BEGIN
			SET @START = @START + 1
			CONTINUE
		END

	   SET @OUTPUT_NAME = REPLACE(@OUTPUT_NAME, CHAR(@START), @EMPTY_STRING)

	   SET @START = @START + 1
	  END
  END

  RETURN @OUTPUT_NAME
END
GO