-- ======================================================================================================================================================================================================
-- author:			�ukasz D�browski
-- company:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				lukaszdabrowski.com
-- creation date:	2016-04-12
-- description:		Removes from input string characters that are different from a-zA-z0-9 as well as CHAR(13)+CHAR(10) and tabulators [ENTER].
--					You can provide customized list of comma separated characters that will be excluded from replacement as well.
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- ======================================================================================================================================================================================================

IF OBJECT_ID('NORMALIZE_NAME') IS NOT NULL
 DROP FUNCTION NORMALIZE_NAME
GO

CREATE FUNCTION NORMALIZE_NAME
(
	@P_INPUT_NAME AS NVARCHAR(MAX),
	@P_LIST_OF_COMMA_SEPARATED_CHARS_TO_EXCLUDE_FROM_REPLACEMENT AS NVARCHAR(MAX) = '#,",;,:,.,$,%,&,*,-'
) RETURNS NVARCHAR(MAX)
AS
BEGIN
 DECLARE 
	@START AS INT = 1,
	@STOP AS INT = 128,
	@EMPTY_STRING AS VARCHAR = '',
	@OUTPUT_NAME AS NVARCHAR(MAX) = ISNULL(@P_INPUT_NAME, '')


 IF @OUTPUT_NAME <> ''
  BEGIN
	 WHILE @START <= @STOP
	  BEGIN
	   IF CHARINDEX(CHAR(@START), @P_LIST_OF_COMMA_SEPARATED_CHARS_TO_EXCLUDE_FROM_REPLACEMENT) > 0
		BEGIN
			SET @START = @START + 1
			CONTINUE
		END

	   IF @START <= 47
		SET @OUTPUT_NAME = REPLACE(@OUTPUT_NAME, CHAR(@START), @EMPTY_STRING)
	   IF @START >= 58 AND @START <= 64
		SET @OUTPUT_NAME = REPLACE(@OUTPUT_NAME, CHAR(@START), @EMPTY_STRING)
	   IF @START >= 91 AND @START <= 96
		SET @OUTPUT_NAME = REPLACE(@OUTPUT_NAME, CHAR(@START), @EMPTY_STRING)
	   IF @START >= 123
		SET @OUTPUT_NAME = REPLACE(@OUTPUT_NAME, CHAR(@START), @EMPTY_STRING)

	   SET @OUTPUT_NAME = REPLACE(@OUTPUT_NAME, '\t', @EMPTY_STRING)

	   SET @START = @START + 1
	  END
  END

  RETURN @OUTPUT_NAME
END