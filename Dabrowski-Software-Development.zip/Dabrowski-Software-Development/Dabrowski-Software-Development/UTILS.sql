-- ===============================================================================================================================================================================================
-- author:			�ukasz D�browski
-- company:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				lukaszdabrowski.com
-- creation date:	2016-06-05
-- description:		Util string functions:
--					R_CHARINDEX -> equivalent of T-SQL CHARINDEX, but starting from the end of the input string.
--					SUBSTRING2 -> equivalent of T-SQL SUBSTRING, but starting from the end of the input string. Optional parameter @P_RIGHT_TO_LEFT_DIRECTION defaults to 1.
--								  Setting @P_RIGHT_TO_LEFT_DIRECTION to 0 changes behaviour of SUBSTRING2 to SUBSTRING function.
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- ===============================================================================================================================================================================================

IF OBJECT_ID('R_CHARINDEX') IS NOT NULL
 DROP FUNCTION R_CHARINDEX
GO

CREATE FUNCTION R_CHARINDEX
(
  @P_CHAR_TO_BE_FOUND AS CHAR,
  @P_INPUT_STRING AS VARCHAR(MAX),
  @P_START_POSITION AS INT = 0
) RETURNS INT
AS
 BEGIN
    DECLARE
		@INPUT_STRING_REVERSED AS VARCHAR(MAX) = REVERSE(@P_INPUT_STRING),
		@POSITION AS INT = -1

		SET @POSITION = CHARINDEX(@P_CHAR_TO_BE_FOUND, @INPUT_STRING_REVERSED, @P_START_POSITION)
		
		RETURN @POSITION
 END


GO

IF OBJECT_ID('SUBSTRING2') IS NOT NULL
 DROP FUNCTION SUBSTRING2
GO

CREATE FUNCTION SUBSTRING2
(
  @P_INPUT_STRING AS NVARCHAR(MAX),
  @P_START_POSITION AS INT = 0,
  @P_LENGTH AS INT = -1,
  @P_RIGHT_TO_LEFT_DIRECTION AS BIT = 1
) RETURNS NVARCHAR(MAX)
AS
 BEGIN
   DECLARE
	@ERROR_TEMPLATE AS VARCHAR(MAX) = '',
	@ERROR_MESSAGE AS VARCHAR(MAX) = ''

   IF @P_START_POSITION < 1
    BEGIN
   		SET @ERROR_TEMPLATE = 'Start position has to be greater than or equal to 1. Current param @P_START_POSITION = ' + CAST(@P_START_POSITION AS VARCHAR(MAX))
		RETURN @ERROR_TEMPLATE
	END

   IF @P_LENGTH < 0 
    BEGIN
   		SET @ERROR_TEMPLATE = 'Length has to be greater than 0. Current param @P_LENGTH = ' + CAST(@P_LENGTH AS VARCHAR(MAX))
		RETURN @ERROR_TEMPLATE
	END

   IF @P_RIGHT_TO_LEFT_DIRECTION = 0 AND @P_START_POSITION > LEN(@P_INPUT_STRING)
    BEGIN
   		SET @ERROR_TEMPLATE = 'Start position has to be less than length of input string. Current param @P_START_POSITION = ' +
							   CAST(@P_START_POSITION AS VARCHAR(MAX)) + ', LEN(@P_INPUT_STRING) = ' +  CAST(LEN(@P_INPUT_STRING) AS VARCHAR(MAX))
		RETURN @ERROR_TEMPLATE
	END

   IF @P_RIGHT_TO_LEFT_DIRECTION = 0 AND  @P_START_POSITION + @P_LENGTH > LEN(@P_INPUT_STRING) + 1
    BEGIN
   		SET @ERROR_TEMPLATE = 'Length cannot exceed length of input string. Param @P_LENGTH value = ' + CAST(@P_LENGTH AS VARCHAR(MAX)) +
							  '. Maximum @P_LENGTH param value = ' + CAST(LEN(@P_INPUT_STRING) + 1 - @P_START_POSITION AS VARCHAR(MAX))
		RETURN @ERROR_TEMPLATE
	END

    --PERFORM ACTUAL OPERATION
	DECLARE
		@INPUT_STRING AS NVARCHAR(MAX) = ''

	IF @P_RIGHT_TO_LEFT_DIRECTION = 1
	 BEGIN
	  SET @INPUT_STRING  = LEFT(RIGHT(@P_INPUT_STRING, @P_START_POSITION), @P_LENGTH)
	 END
	ELSE
	 BEGIN
	  SET @INPUT_STRING  = SUBSTRING(@P_INPUT_STRING, @P_START_POSITION, @P_LENGTH)
	 END

	RETURN @INPUT_STRING
 END