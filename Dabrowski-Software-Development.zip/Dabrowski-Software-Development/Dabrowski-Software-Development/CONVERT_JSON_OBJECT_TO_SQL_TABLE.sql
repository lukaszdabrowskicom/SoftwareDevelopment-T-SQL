-- ======================================================================================================================================================================================================
-- author:			�ukasz D�browski
-- company:			DABROWSKI SOFTWARE DEVELOPMENT
-- www:				lukaszdabrowski.com
-- creation date:	2016-05-13
-- description:		Converts data in the form of JSON format to a table. Support for SQL SERVER versions prior to SQL SERVER 2016.
--					End user is resposible for providing unique temporary table in the server context, bacause there is no unique solution to pick up the correct table
--					in case multiple sessions would create temp tables with the same name (SQL SERVER temp tables nature) in the same relatively short period of time.
--					"null" values in JSON object are converted to ___NULL___ literal. It is end-user responsibility to handle this value appropriately.
--					Date & time values are handled as in T-SQL, datetime value have to be separated with uppercase T letter, i.e. "2016-05-14T22:29:34"R
--					This procedure depends on dbo.NORMALIZE_NAME and dbo.GET_COLUMN_TYPE_BASED_ON_DATA_TYPE functions, which are included in this solution.	
--                  Due to implementation details of handling null values [___NULL___] columns of type CHAR, NCHAR, VARCHAR and NVARCHAR that have null values in JSON object have to have column size of at least 10 characters.	
--					This version recognizes simple array of object, where each object consists of key-value pairs without any nesting. Example below:
--																																[
--																																   {
--																																	"property1": "value 1",
--																																	"property2": "value 2",
--																																	"property3": "null",
--																																	"property_date": "2016-05-14",
--																																	"property_time": "22:29:34",
--																																	"property_datetime": "2016-05-14T22:29:34",
--																																				.
--																																				.
--																																				.
--																																   },
--																																   {
--																																	 "property1": "value 1",
--																																	 "property2": "value 2"
--																																				.
--																																				.
--																																				.
--																																   }
--																																]
--					
-- WARNING:			Average execution time for collection of ~400 items with 12 properties each is ~9 seconds.
--					
-- version:			1.0.0
-- license:			MIT (http://www.opensource.org/licenses/mit-license.php)
-- feedback:		contact@lukaszdabrowski.com
-- =======================================================================================================================================================================================================

IF OBJECT_ID ('CONVERT_JSON_OBJECT_TO_SQL_TABLE') IS NOT NULL
 DROP PROC CONVERT_JSON_OBJECT_TO_SQL_TABLE
GO

CREATE PROCEDURE CONVERT_JSON_OBJECT_TO_SQL_TABLE
(
 @P_TEMP_TABLE_CREATED_TO_STORE_JSON_OBJECT AS SYSNAME,
 @P_JSON_COLLECTION AS NVARCHAR(MAX)
)
AS
BEGIN
	   SET NOCOUNT ON;

	   DECLARE
		@ERROR_TEMPLATE AS NVARCHAR(MAX) = '',
		@ERROR_MESSAGE AS NVARCHAR(MAX) = ''

	   IF NOT EXISTS (
			SELECT 1/0
			FROM tempdb.INFORMATION_SCHEMA.TABLES AS T
			WHERE T.TABLE_NAME LIKE @P_TEMP_TABLE_CREATED_TO_STORE_JSON_OBJECT + '%'
	   )
		BEGIN
			SET @ERROR_TEMPLATE = 'Temporary table ' + CAST(@P_TEMP_TABLE_CREATED_TO_STORE_JSON_OBJECT AS VARCHAR(MAX)) + ' does not exist.'
			SET @ERROR_MESSAGE = ''
	   		RAISERROR (
						@ERROR_TEMPLATE,
						16,
						1,
						@ERROR_TEMPLATE,
						N''
					  )
			 RETURN
		END
		
		--VALIDATE JSON COLLECTION
		DECLARE @EMPTY_STRING AS VARCHAR = ''
		DECLARE @ENTER AS CHAR(2) = CHAR(13)+CHAR(10)
		DECLARE @TABULATOR AS CHAR(1) = '\t'
		DECLARE @JSON_COLLECTION AS NVARCHAR(MAX) = REPLACE(REPLACE(LTRIM(RTRIM(@P_JSON_COLLECTION)), @ENTER, ''), @TABULATOR, @EMPTY_STRING)
		DECLARE @JSON_COLLECTION_LENGTH AS INT = LEN(@JSON_COLLECTION)
		DECLARE @COMMA AS CHAR(1) = ','
		DECLARE @COLON AS CHAR(1) = ':'
		DECLARE @QUOTATION AS CHAR(1) = '"'
		DECLARE @OPENING_CURLY_BRACE AS CHAR(1) = '{'
		DECLARE @CLOSING_CURLY_BRACE AS CHAR(1) = '}'
		DECLARE @JSON_PROPERTY_NULL_VALUE AS CHAR(4) = 'null'
		DECLARE @NULL_CONSTANT AS CHAR(10) = '___NULL___'
		
		DECLARE @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET AS BIT = 0
		
		IF ((@JSON_COLLECTION_LENGTH - LEN(REPLACE(REPLACE(@JSON_COLLECTION, @OPENING_CURLY_BRACE, @EMPTY_STRING), @CLOSING_CURLY_BRACE, @EMPTY_STRING))) / LEN(@COMMA)) % 2 = 0
		 SET @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET = 1

	    IF @EACH_OPENING_CURLY_BRACKET_HAS_ITS_ENDING_CURLY_BRACKET = 0
		 BEGIN
			SET @ERROR_TEMPLATE = 'JSON collection does not represent valid JSON. Number of opening and closing curly brackets mismatch.'
			SET @ERROR_MESSAGE = ''
	   		RAISERROR (
						@ERROR_TEMPLATE,
						16,
						1,
						@ERROR_TEMPLATE,
						N''
					  )
			 RETURN
		 END
		
		--REMOVE FIRST OPENING AND LAST CLOSING SQUARE BRACKET
		SET @JSON_COLLECTION = RIGHT(@JSON_COLLECTION, LEN(@JSON_COLLECTION) - 1)
		SET @JSON_COLLECTION = LEFT(@JSON_COLLECTION, LEN(@JSON_COLLECTION) - 1)
		SET @JSON_COLLECTION = LTRIM(RTRIM(@JSON_COLLECTION)) + @COMMA
		
		--INSERT EACH OBJECT INTO TABLE
		CREATE TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL(ID INT, JSON_ITEM NVARCHAR(MAX))
		INSERT #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
		SELECT
			JT.ID,
			JT.CUSTOM_COLUMN 
		FROM dbo.CREATE_CUSTOM_TABLE(@JSON_COLLECTION, DEFAULT, DEFAULT, DEFAULT, DEFAULT) AS JT


		--EXTRACT FROM EACH OBJECT KEY AND VALUE AND PUT IT INTO TABLE
		UPDATE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
		 SET JSON_ITEM = REPLACE(REPLACE(JSON_ITEM, @OPENING_CURLY_BRACE, @EMPTY_STRING), @CLOSING_CURLY_BRACE, @EMPTY_STRING)
		
		UPDATE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL
		 SET JSON_ITEM = dbo.NORMALIZE_NAME(JSON_ITEM, DEFAULT)

		ALTER TABLE #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL ADD PROPERTY_NAME NVARCHAR(MAX), PROPERTY_VALUE NVARCHAR(MAX) 
		
		UPDATE JICTTI
		 SET
			JICTTI.PROPERTY_NAME = SUBSTRING(JICTTI.JSON_ITEM, CHARINDEX(@QUOTATION, JICTTI.JSON_ITEM) + 1, CHARINDEX(@COLON, JICTTI.JSON_ITEM) - 3),
			JICTTI.PROPERTY_VALUE = 
						NULLIF(SUBSTRING(JICTTI.JSON_ITEM,
								  CHARINDEX(@COLON, JSON_ITEM, 0) + 2,
								  CHARINDEX(@QUOTATION, JICTTI.JSON_ITEM, CHARINDEX(@COLON, JSON_ITEM, 0) + 2) - (CHARINDEX(@COLON, JSON_ITEM, 0) + 2)
								 ),
								 @JSON_PROPERTY_NULL_VALUE
							  )
		FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI


		--PERFORM PIVOT-LIKE OPERATION
		DECLARE 
			@MIN_ORDINAL_POSITION AS INT = 1,
			@MIN_ORDINAL_POSITION_TO_STRING AS VARCHAR(MAX) = '',
			@MAX_ORDINAL_POSITION AS INT = -1,
			@COLUMN_NAME AS SYSNAME = '',
			@DATA_TYPE AS SYSNAME = '',
			@COLUMN_FULL_TYPE AS SYSNAME = ''

		SELECT 
			T.ORDINAL_POSITION,
			T.COLUMN_NAME,
			T.DATA_TYPE
		INTO #EXTERNAL_USER_TABLE
		FROM tempdb.INFORMATION_SCHEMA.COLUMNS AS T
		WHERE T.TABLE_NAME LIKE @P_TEMP_TABLE_CREATED_TO_STORE_JSON_OBJECT + '%'

		SELECT @MAX_ORDINAL_POSITION = MAX(EUT.ORDINAL_POSITION)
									   FROM #EXTERNAL_USER_TABLE AS EUT

		DECLARE @DYNAMIC_INSERT_QUERY_HEADER AS NVARCHAR(MAX) = 'INSERT ' + @P_TEMP_TABLE_CREATED_TO_STORE_JSON_OBJECT
		DECLARE @DYNAMIC_INSERT_QUERY AS NVARCHAR(MAX) = ' SELECT '


		--CREATE SELECT STATEMENT CONSISTING OF ALL THE COLUMNS IN THE TABLE
		WHILE @MIN_ORDINAL_POSITION <= @MAX_ORDINAL_POSITION
		 BEGIN
			SELECT
				@COLUMN_NAME = EUT.COLUMN_NAME,
				@DATA_TYPE = EUT.DATA_TYPE
			FROM #EXTERNAL_USER_TABLE AS EUT
			WHERE EUT.ORDINAL_POSITION = @MIN_ORDINAL_POSITION

			SET @COLUMN_FULL_TYPE =  dbo.GET_COLUMN_TYPE_BASED_ON_DATA_TYPE(@COLUMN_NAME, @DATA_TYPE, @P_TEMP_TABLE_CREATED_TO_STORE_JSON_OBJECT, 1)

			SET @MIN_ORDINAL_POSITION_TO_STRING = CAST(@MIN_ORDINAL_POSITION AS VARCHAR(MAX))
			SET @DYNAMIC_INSERT_QUERY = @DYNAMIC_INSERT_QUERY + 'CAST({_________________$' + @MIN_ORDINAL_POSITION_TO_STRING + '} AS ' + @COLUMN_FULL_TYPE + '), '

			SET @MIN_ORDINAL_POSITION = @MIN_ORDINAL_POSITION + 1
		 END
		 
		 SET @DYNAMIC_INSERT_QUERY = RTRIM(@DYNAMIC_INSERT_QUERY)

		 SET @DYNAMIC_INSERT_QUERY = LEFT(@DYNAMIC_INSERT_QUERY, LEN(@DYNAMIC_INSERT_QUERY) - 1)


		--FOR EACH ROW SUBSTITUTE PLACEHOLDERS IN THE SELECT WITH ACTUAL VALUES AND INSERT A ROW INTO TABLE
		DECLARE 
			@JSON_OBJECT_LAST_PROPERTY_ID AS INT = @MAX_ORDINAL_POSITION,
			@JSON_DATA_FIRST_ROW AS INT = 1,
			@JSON_DATA_FIRST_ROW_TO_STRING AS VARCHAR(MAX) = '',
			@JSON_DATA_LAST_ROW AS INT = -1,
			@INSER_QUERY AS NVARCHAR(MAX) = '',
			@PROPERTY_VALUE AS NVARCHAR(MAX) = '',
			@DO_REPLACEMENT_WITH_DIVISION AS INT = 0
	
		SELECT @JSON_DATA_LAST_ROW = MAX(JICTTI.ID)
									 FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI


		SET @INSER_QUERY = @INSER_QUERY + @DYNAMIC_INSERT_QUERY
		WHILE @JSON_DATA_FIRST_ROW <= @JSON_DATA_LAST_ROW
		 BEGIN
		  SELECT @PROPERTY_VALUE = ISNULL(JICTTI.PROPERTY_VALUE, @NULL_CONSTANT)
									FROM #JSON_ITEM_COLLECTION_TO_TABLE_INTERNAL AS JICTTI
									WHERE JICTTI.ID = @JSON_DATA_FIRST_ROW

		  IF @DO_REPLACEMENT_WITH_DIVISION = 0
		    BEGIN
				SET @JSON_DATA_FIRST_ROW_TO_STRING = CAST(@JSON_DATA_FIRST_ROW AS VARCHAR(MAX))
				SET @INSER_QUERY = REPLACE(@INSER_QUERY, '{_________________$' + @JSON_DATA_FIRST_ROW_TO_STRING  + '}', ''''+ @PROPERTY_VALUE + '''')
			END
		  ELSE
		    BEGIN
				SET @JSON_DATA_FIRST_ROW_TO_STRING = CAST((@JSON_DATA_FIRST_ROW - @MAX_ORDINAL_POSITION * @DO_REPLACEMENT_WITH_DIVISION)  AS VARCHAR(MAX))
				SET @INSER_QUERY = REPLACE(@INSER_QUERY, '{_________________$' + @JSON_DATA_FIRST_ROW_TO_STRING + '}', '''' +  @PROPERTY_VALUE + '''')
			END

		  SET @PROPERTY_VALUE = ''
		  IF @JSON_OBJECT_LAST_PROPERTY_ID = @JSON_DATA_FIRST_ROW --CURRENT OBJECT LAST PROPERTY WAS RETREIVED, SO INSERT FLAT DATA
		  BEGIN
			
			SET @INSER_QUERY = @DYNAMIC_INSERT_QUERY_HEADER + @INSER_QUERY
			EXEC(@INSER_QUERY)

			SET @JSON_OBJECT_LAST_PROPERTY_ID = @JSON_OBJECT_LAST_PROPERTY_ID + @MAX_ORDINAL_POSITION
			SET @DO_REPLACEMENT_WITH_DIVISION = @DO_REPLACEMENT_WITH_DIVISION + 1
			SET @INSER_QUERY = ''
			SET @INSER_QUERY = @INSER_QUERY + @DYNAMIC_INSERT_QUERY
		  END

		  SET @JSON_DATA_FIRST_ROW = @JSON_DATA_FIRST_ROW + 1
		 END
END